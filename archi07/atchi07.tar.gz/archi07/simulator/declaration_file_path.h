#ifndef __DECLARATION_FILE_PATH_H
#define __DECLARATION_FILE_PATH_H

#define PATH_DIMAGE_bin "./dimage.bin"
#define PATH_IIMAGE_bin "./iimage.bin"
#define PATH_SNAPSHOT_rpt "./snapshot.rpt"
#define PATH_ERROR_DUMP_rpt "./error_dump.rpt"

#endif
