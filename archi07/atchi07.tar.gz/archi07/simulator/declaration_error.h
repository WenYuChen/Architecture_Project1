#ifndef __DECLARATION_ERROR_H
#define __DECLARATION_ERROR_H

#define ERROR_write_to_register_zero 0
#define ERROR_number_overflow 1
#define ERROR_memory_address_overflow 2
#define ERROR_data_misaligned 3

#endif
